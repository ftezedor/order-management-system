package com.acme.order.bootstrap.spring.rest.listener;

import com.acme.order.domain.event.OrderCreatedEvent;
import com.acme.order.infrastructure.persistence.adapter.JpaOutboxAdapter;
import com.acme.order.infrastructure.persistence.outbox.OutboxEntity;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


@Component // This makes it a standalone bean managed by Spring
public class OrderEventListener {

    /*
    private final RabbitMqOrderPublisher rabbitMqOrderPublisher;

    public OrderEventListener(RabbitMqOrderPublisher rabbitMqOrderPublisher, JpaOutboxAdapter outboxAdapter) {
        this.outboxAdapter = outboxAdapter;
        this.rabbitMqOrderPublisher = rabbitMqOrderPublisher;
    }
    */

    private final JpaOutboxAdapter outboxAdapter;

    public OrderEventListener(JpaOutboxAdapter outboxAdapter) {
        this.outboxAdapter = outboxAdapter;
    }

    @EventListener
    @Transactional
    public void onOrderCreated(OrderCreatedEvent event) {
        // directly publish got replaced by outbox strategy so that we can handle retries
        //rabbitMqOrderPublisher.handle(event);

        OutboxEntity outbox = new OutboxEntity();
        outbox.setAggregateType("ORDER");
        outbox.setEventType("OrderCreated");
        // Convert event to JSON string
        outbox.setPayload(String.format("{\"orderId\":\"%s\"}", event.orderId()));
        
        outboxAdapter.save(outbox);
    }
}