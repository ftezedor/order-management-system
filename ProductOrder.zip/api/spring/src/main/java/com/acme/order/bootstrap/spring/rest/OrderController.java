package com.acme.order.bootstrap.spring.rest;

import com.acme.order.domain.model.Order;
import com.acme.order.domain.ports.in.CreateOrderCommand;
import com.acme.order.domain.ports.in.CreateOrderUseCase;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/v1/orders")
public class OrderController {

    private final CreateOrderUseCase createOrderUseCase;

    public OrderController(CreateOrderUseCase createOrderUseCase) {
        this.createOrderUseCase = createOrderUseCase;
    }

    @PostMapping
    @Transactional
    public ResponseEntity<Order> createOrder(@RequestBody CreateOrderCommand command) {
        Order order = createOrderUseCase.execute(command);
        return ResponseEntity.ok(order);
    }
}