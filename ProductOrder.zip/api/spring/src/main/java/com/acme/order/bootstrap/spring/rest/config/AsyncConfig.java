package com.acme.order.bootstrap.spring.rest.config;

import java.util.Map;
import java.util.concurrent.Executor;
import org.slf4j.MDC;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;


/*
 * OutboxRelay uses @Async. By default, MDC is thread-local and will not move to the background thread. We fix this in the Bootstrap layer with a TaskDecorator.
 */
@Configuration
@EnableAsync
public class AsyncConfig {
    @Bean
    public Executor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setTaskDecorator(runnable -> {
            // This captures the MDC from the main thread...
            Map<String, String> contextMap = MDC.getCopyOfContextMap();
            return () -> {
                try {
                    // ...and restores it in the async thread.
                    if (contextMap != null) MDC.setContextMap(contextMap);
                    runnable.run();
                } finally {
                    MDC.clear();
                }
            };
        });
        executor.initialize();
        return executor;
    }
}