package com.acme.order.bootstrap.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EntityScan(basePackages = { "com.acme.order.infrastructure.persistence.jpa",
        "com.acme.order.bootstrap.spring", // Scan for any bootstrap entities
        "com.acme.order.infrastructure.persistence" })
@EnableJpaRepositories(basePackages = "com.acme.order.infrastructure.persistence.jpa")
public class OrderApplication {
    public static void main(String[] args) {
        SpringApplication.run(OrderApplication.class, args);
    }
}
